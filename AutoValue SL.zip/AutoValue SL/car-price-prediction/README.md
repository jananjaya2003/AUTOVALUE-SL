# AutoValue SL — Car Price Prediction

A complete final-year ML project predicting used car prices in Sri Lanka.
Best model: Gradient Boosting — Test R² = 0.875

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Train the model
python -m src.train_models

# 3. Generate charts
python -m src.evaluate_models

# 4. Run web app from the project root
cd ..
python app.py
# Open: http://localhost:5000
```

## Results

| Model | Test R² | Status |
|---|---|---|
| Gradient Boosting ★ | 0.8750 | Good Fit |
| Random Forest | 0.8737 | Good Fit |
| Extra Trees | 0.8617 | Good Fit |
| Decision Tree | 0.8462 | Good Fit |
| Linear Regression | 0.6796 | Underfitting |
| SVR | 0.4896 | Underfitting |

## Dataset
- 9,788 Sri Lankan vehicle listings
- 22 engineered features
- Target: Price in LKR Lakhs

## Structure
```
car-price-prediction/
├── data/          ← Dataset CSV
├── src/           ← Python modules
├── models/        ← Trained model (auto-generated)
├── templates/     ← Flask HTML pages
├── static/        ← CSS, JS, charts
├── reports/       ← Academic reports & viva Q&A
├── app.py         ← Flask entry point
└── requirements.txt
```

## API
POST /api/predict with JSON body containing car attributes → returns predicted_price_lakhs



python app.py --train once to train and save the model
python app.py after that to start the app and use predictions