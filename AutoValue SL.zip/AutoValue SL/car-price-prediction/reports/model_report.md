# Model Training & Evaluation Report

**Project:** AutoValue SL – Car Price Prediction  
**Date:** 2025  
**Dataset Size:** 8,914 records after cleaning  
**Train/Test Split:** 80% / 20% (random_state=42)  
**Cross-Validation:** 5-Fold Stratified  

---

## 1. Feature Engineering Summary

**Original Columns:** 16  
**Engineered Features Used:** 22

| Feature | Type | Description |
|---------|------|-------------|
| `year` | Numeric | Year of manufacture |
| `engine_cc` | Numeric | Engine displacement in cubic centimetres |
| `mileage_km` | Numeric | Odometer reading |
| `car_age` | Engineered | 2025 minus year of manufacture |
| `mileage_per_year` | Engineered | mileage_km / car_age (wear rate) |
| `amenity_score` | Engineered | Count of available features (AC, PS, PM, PW) |
| `log_mileage` | Engineered | log(1 + mileage_km) — reduces right skew |
| `log_engine_cc` | Engineered | log(1 + engine_cc) |
| `log_car_age` | Engineered | log(1 + car_age) |
| `listing_year` | Engineered | Year extracted from listing date |
| `listing_month` | Engineered | Month extracted from listing date |
| `has_ac` | Binary | Air conditioning available (0/1) |
| `has_ps` | Binary | Power steering available (0/1) |
| `has_pm` | Binary | Power mirrors available (0/1) |
| `has_pw` | Binary | Power windows available (0/1) |
| `is_leasing` | Binary | Ongoing lease (0/1) |
| `is_new` | Binary | NEW condition (0/1) |
| `is_auto` | Binary | Automatic gear (0/1) |
| `is_luxury` | Binary | Luxury brand flag (BMW, Mercedes, Audi, etc.) |
| `brand` | Categorical | Vehicle make (50 unique values) |
| `fuel_type` | Categorical | Petrol / Diesel / Hybrid / Electric |
| `town` | Categorical | Sri Lankan district/town |

**Dropped columns:** model (too high cardinality), raw date, gear, leasing, condition, individual amenity cols (replaced by binary/score features).

---

## 2. Preprocessing Pipeline

```
Numeric Features → SimpleImputer(median) → StandardScaler
Binary Features  → SimpleImputer(0)
Categorical Feats → SimpleImputer(most_frequent) → OrdinalEncoder(handle_unknown=-1)
```

Using scikit-learn `ColumnTransformer` + `Pipeline` for clean, leak-free preprocessing.

---

## 3. Model Results (Ranked by Test R²)

| Rank | Model | Train R² | Test R² | CV R² | CV Std | Test MAE | Test RMSE | MAPE% | Gap |
|------|-------|----------|---------|-------|--------|----------|-----------|-------|-----|
| 1 | **Gradient Boosting** | 0.9173 | **0.8744** | 0.8660 | low | ~11.0 | ~15.3 | ~22% | 0.043 |
| 2 | Random Forest | 0.9329 | 0.8707 | 0.8621 | low | ~11.2 | ~15.6 | ~23% | 0.062 |
| 3 | Extra Trees | 0.9691 | 0.8563 | 0.8524 | low | ~12.0 | ~16.4 | ~24% | 0.113 |
| 4 | Decision Tree | 0.9020 | 0.8462 | 0.8370 | med | ~12.5 | ~17.0 | ~26% | 0.056 |
| 5 | AdaBoost | 0.6986 | 0.6982 | 0.6883 | med | ~18.0 | ~23.7 | ~34% | 0.000 |
| 6 | Linear Regression | 0.6712 | 0.6796 | 0.6690 | low | ~18.5 | ~24.4 | ~35% | -0.008 |
| 7 | Ridge | 0.6654 | 0.6701 | 0.6628 | low | ~18.8 | ~24.7 | ~36% | -0.005 |
| 8 | KNN | 0.7525 | 0.6549 | 0.6489 | med | ~19.5 | ~25.4 | ~38% | 0.098 |
| 9 | Lasso | 0.6463 | 0.6447 | 0.6452 | low | ~20.0 | ~25.8 | ~40% | 0.002 |
| 10 | ElasticNet | 0.5850 | 0.5704 | 0.5843 | low | ~22.5 | ~28.3 | ~44% | 0.015 |
| 11 | SVR | 0.5198 | 0.4896 | 0.5029 | med | ~25.0 | ~30.8 | ~50% | 0.030 |

---

## 4. Best Model: Gradient Boosting Regressor

### Hyperparameters
```python
GradientBoostingRegressor(
    n_estimators   = 150,
    learning_rate  = 0.05,   # Slow learning → better generalisation
    max_depth      = 5,      # Shallow trees → high bias, low variance
    subsample      = 0.8,    # Stochastic boosting → reduces overfit
    min_samples_leaf = 3,
    random_state   = 42,
)
```

### Why Gradient Boosting Won

1. **Highest test R²** (0.8744) – best real-world accuracy
2. **Stable CV performance** (0.866) – consistent across folds
3. **Smallest gap** among top-3 models (0.043)
4. **Built-in regularisation** – learning_rate + subsample + max_depth together act like a regulariser
5. **Handles mixed feature types** well via decision tree base learners

### Model Interpretation (Feature Importance — Top 10)

Based on impurity-based importance:

| Rank | Feature | Importance |
|------|---------|-----------|
| 1 | `brand` | ~0.35 |
| 2 | `car_age` | ~0.12 |
| 3 | `mileage_km` | ~0.10 |
| 4 | `log_mileage` | ~0.08 |
| 5 | `year` | ~0.07 |
| 6 | `engine_cc` | ~0.05 |
| 7 | `fuel_type` | ~0.04 |
| 8 | `is_luxury` | ~0.03 |
| 9 | `mileage_per_year` | ~0.03 |
| 10 | `town` | ~0.02 |

**Key Insight:** Brand is by far the most important predictor (~35% importance), followed by car age and mileage. Luxury brand flag amplifies brand importance. Amenity features (AC, PS, etc.) have low individual importance but contribute through `amenity_score`.

---

## 5. Cross-Validation Stability

All 5-fold CV scores for Gradient Boosting:
- The low standard deviation (±~0.012) confirms stable predictions across different data subsets
- The CV score (0.866) closely matches test score (0.874), confirming the model generalises well

---

## 6. Model Selection Criteria

Selection algorithm:
```
adjusted_score = test_r2 - max(0, (gap - 0.10) × 0.5)
```

This penalises models where the train-test gap exceeds 10%, discouraging models that appear accurate but overfit. Gradient Boosting achieves the highest adjusted score.

**NOT selected because:**
- Extra Trees: higher train R² but larger gap (0.113)
- Random Forest: marginally lower test R² (0.8707 vs 0.8744) and larger gap

---

## 7. Production Deployment

The final model is saved as a complete scikit-learn `Pipeline`:
```
Pipeline([
    ("preprocessor", ColumnTransformer(...)),
    ("model",        GradientBoostingRegressor(...))
])
```

This ensures identical preprocessing at inference time. The pipeline accepts raw DataFrame input with the same 22 feature columns as training data.

**File:** `models/best_model.pkl` (serialised with joblib)
