# Overfitting and Underfitting Analysis Report
## AutoValue SL — Car Price Prediction

---

## 1. Summary

| Model | Train R² | Test R² | Gap | Status |
|---|---|---|---|---|
| Gradient Boosting | 0.9250 | 0.8750 | 0.0500 | ✅ Good Fit |
| Random Forest | 0.9305 | 0.8737 | 0.0568 | ✅ Good Fit |
| Extra Trees | 0.9317 | 0.8617 | 0.0700 | ✅ Good Fit |
| Decision Tree | 0.9020 | 0.8462 | 0.0558 | ✅ Good Fit |
| AdaBoost | 0.7087 | 0.7122 | -0.0035 | ✅ Good Fit |
| Linear Regression | 0.6712 | 0.6796 | -0.0084 | ⚠️ Underfitting |
| Ridge | 0.6704 | 0.6768 | -0.0064 | ⚠️ Underfitting |
| Lasso | 0.6617 | 0.6666 | -0.0049 | ⚠️ Underfitting |
| ElasticNet | 0.6322 | 0.6266 | 0.0056 | ⚠️ Underfitting |
| KNN | 0.7525 | 0.6549 | 0.0976 | ✅ Good Fit |
| SVR | 0.5198 | 0.4896 | 0.0302 | ⚠️ Underfitting |

---

## 2. Overfitting Analysis

**Definition:** A model overfits when Train R² >> Test R² (gap > 0.15), indicating memorisation of training noise.

**Findings:** No model in the final comparison exceeded the 0.15 overfitting threshold. The largest gap was Extra Trees at 0.070. This was achieved through deliberate regularisation applied before evaluation:

### Techniques Applied to Control Overfitting:

**For Decision Tree:**
- `max_depth=10` (prevents infinite depth memorisation)
- `min_samples_split=10` (requires 10+ samples for a split)
- `min_samples_leaf=5` (requires 5+ samples in each leaf)

**For Random Forest:**
- `max_depth=15`
- `max_features=0.7` (only 70% of features considered per split — reduces tree correlation)
- `min_samples_split=5`, `min_samples_leaf=3`
- 200 estimators with bagging (averaging reduces variance)

**For Extra Trees:**
- Same depth and sample constraints as Random Forest
- Extra randomness in split selection further reduces overfitting

**For Gradient Boosting:**
- `subsample=0.8` — each tree sees only 80% of training data (stochastic boosting)
- `learning_rate=0.05` — slow learning prevents individual trees from dominating
- `max_depth=5` — shallow trees are weak learners (by design)
- 200 estimators at low learning rate > 50 estimators at high learning rate

---

## 3. Underfitting Analysis

**Definition:** A model underfits when Train R² < 0.70, indicating it cannot capture the patterns in training data.

**Underfitting Models:** Linear Regression, Ridge, Lasso, ElasticNet, SVR

**Root Cause:** Car pricing involves complex non-linear interactions:
- Brand × Year interaction (a 2020 BMW is worth disproportionately more than a 2020 Micro)
- Mileage × Age interaction (10,000 KM at age 1 vs age 10 have different meanings)
- Fuel type premium (hybrid cars command a market premium beyond their features)

Linear models assume: price = w1×year + w2×mileage + w3×engine + ... which cannot capture these interactions.

### Techniques Applied to Address Underfitting:

1. **Log transformations** added (log_mileage, log_engine_cc, log_car_age) to linearise skewed distributions
2. **Interaction-like features** added (mileage_per_year, amenity_score, is_luxury flag)
3. **Regularisation tuning** — excessive regularisation was checked (Lasso alpha tested at 0.001–10)
4. **Despite all efforts**, max linear model test R² was 0.68, confirming the problem requires non-linear models

---

## 4. Actions and Outcomes

| Action | Target Issue | Result |
|---|---|---|
| max_depth constraints | Overfitting in trees | Gap reduced from ~0.20 to ~0.06 |
| subsample in GBM | Overfitting in boosting | Consistent CV and test scores |
| Log transforms | Underfitting in linear | +2-3% R² improvement in linear models |
| is_luxury feature | Underfitting (brand signal) | Improved linear model performance |
| RandomizedSearchCV | Both issues | Optimal hyperparameter balance found |
| 5-fold CV in model selection | Overfitting in selection | Prevents lucky test split bias |
| Feature drop (model col) | Overfitting (high cardinality) | Removed spurious signal |

---

## 5. Final Conclusion

The project successfully demonstrated detection and mitigation of both overfitting and underfitting:

- **Overfitting** was controlled in tree models through depth limits, sample constraints, and stochastic regularisation. No final model has a train-test gap > 0.10.
- **Underfitting** was addressed in linear models through feature engineering, but fundamentally confirms that this problem requires non-linear models.
- **Best generalisation** is achieved by Gradient Boosting with train R²=0.925, test R²=0.875, gap=0.050 — a strong, well-calibrated model.
- The **learning curve** shows training and validation R² converge as training size increases, confirming the model generalises rather than memorises.
