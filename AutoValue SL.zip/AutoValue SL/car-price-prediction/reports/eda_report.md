# Exploratory Data Analysis Report
## Car Price Prediction — Sri Lankan Vehicle Market

---

## Dataset Overview
- **Records:** 9,788 raw → 8,914 after cleaning
- **Features:** 16 raw columns → 22 engineered features
- **Target:** Price (LKR Lakhs)
- **Date Range:** 2024–2025 listings

## Price Distribution
- Min: 4 LKR Lakhs | Max: 225 LKR Lakhs (after outlier removal)
- Mean: 54.29 LKR Lakhs | Median: ~43 LKR Lakhs
- Distribution is **right-skewed** (most cars are budget segment, few premium)
- Log-transformed price is approximately normal

## Top Brands by Volume
1. TOYOTA (3,089 listings) — 31.6%
2. SUZUKI (2,473 listings) — 25.3%
3. NISSAN (1,248 listings) — 12.8%
4. HONDA (681 listings)
5. MITSUBISHI (284 listings)

## Key Correlations with Price
| Feature | Correlation |
|---|---|
| is_luxury | +0.52 |
| year | +0.49 |
| engine_cc | +0.45 |
| car_age | -0.49 |
| mileage_km | -0.35 |
| is_auto | +0.28 |

## Categorical Feature Insights
- **Fuel Type:** Hybrid/Electric cars command 25-40% premium over Petrol
- **Gear:** Automatic cars priced ~30% higher than Manual on average
- **Condition:** New cars priced 2-3x higher than used
- **Town:** Colombo and Gampaha listings tend to be higher-priced

## Data Quality
- Zero missing values in original dataset
- 18 exact duplicates removed (0.18%)
- 110 price outliers removed (top 1%, >225 Lakhs)
- Small number of pre-1990 vehicles removed (<0.3%)

## Feature Engineering Insights
- `car_age` is more predictive than raw `year` alone
- `mileage_per_year` adds signal beyond raw mileage
- `is_luxury` flag captures brand tier clustering clearly
- `amenity_score` aggregation reduces dimensionality without losing signal
