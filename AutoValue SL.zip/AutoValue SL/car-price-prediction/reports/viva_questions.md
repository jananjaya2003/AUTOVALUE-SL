# VIVA QUESTIONS & ANSWERS
## Car Price Prediction — AutoValue SL

---

### Q1. Why did you choose Gradient Boosting as your final model?
**A:** Gradient Boosting achieved the best test R² (0.875) with the smallest train-test gap (0.05) among all models tested. Unlike Random Forest which achieved similar test R², Gradient Boosting showed more consistent cross-validation scores (0.868 CV vs 0.864 for RF), indicating better stability. I selected based on test performance and generalisation gap, not training accuracy, to avoid choosing an overfitted model.

### Q2. What is overfitting and how did you detect it?
**A:** Overfitting is when a model learns the training data too well — including its noise — and fails to generalise to new data. I detected it by: (1) comparing training R² vs test R², (2) analysing cross-validation scores vs training scores, (3) plotting learning curves to see if training and validation curves diverged, and (4) examining residual plots for patterns. A gap of >0.15 between train and test R² was my threshold for flagging overfitting.

### Q3. How did you prevent overfitting in tree-based models?
**A:** I applied multiple regularisation techniques: (1) limiting `max_depth` to prevent trees from becoming too deep, (2) setting `min_samples_split` and `min_samples_leaf` to prevent splits on tiny subsets, (3) using `subsample=0.8` in Gradient Boosting (stochastic boosting introduces randomness), (4) limiting `max_features=0.7` in Random Forest (feature randomisation reduces correlation between trees), and (5) using 5-fold cross-validation during tuning to penalise models that overfit their tuning set.

### Q4. Why did linear models underperform?
**A:** Car pricing is fundamentally non-linear. For example, a luxury brand car from 2022 with 10,000 KM doesn't price at a simple linear combination of those features — brand and recency interact multiplicatively. Linear models (Linear Regression, Ridge, Lasso) assume feature-price relationships are additive and linear, which this data violates. Even with log transformations of skewed features, the maximum linear model test R² was 0.68, vs 0.875 for Gradient Boosting.

### Q5. What is cross-validation and why did you use it?
**A:** Cross-validation (k-fold) is a technique where training data is split into k equal parts. The model trains on k-1 parts and validates on the held-out part, repeating k times. I used 5-fold CV because: (1) it gives a more reliable estimate of generalisation than a single train-test split, (2) it uses all training data for both training and validation, (3) it reduces the influence of a lucky or unlucky random split, and (4) it provides a standard deviation of performance scores revealing model stability.

### Q6. Explain your feature engineering choices.
**A:** I engineered 22 features from 16 raw columns. Key decisions: `car_age` (2025 – year) is more meaningful than raw year; `mileage_per_year` captures wear rate better than absolute mileage; `amenity_score` combines 4 binary features into one informative ordinal feature; `is_luxury` encodes brand prestige category; log transforms of mileage/engine/age linearise their skewed distributions to help linear models; `listing_month` captures seasonal market patterns.

### Q7. What is the difference between MAE and RMSE? Which is more useful here?
**A:** MAE (Mean Absolute Error) is the average absolute difference between predicted and actual values — it treats all errors equally. RMSE (Root Mean Squared Error) penalises large errors more heavily due to squaring. For car price prediction, RMSE is arguably more important because severely wrong predictions (e.g., predicting 20 Lakhs for a 100 Lakh car) are much more harmful than moderate errors. However, MAE is more interpretable — our MAE of 7.36 Lakhs means on average the prediction is off by 7.36 LKR Lakhs.

### Q8. Why did you drop the `model` column (car model name)?
**A:** The `model` column had hundreds of unique values (high cardinality). Using it directly would either: (1) if one-hot encoded, create hundreds of sparse features causing overfitting on rare models, or (2) if ordinally encoded, impose artificial ordinal relationships between model names that don't exist. The `brand` column captures most of the pricing signal. In a future version, model-level encoding could be incorporated via target encoding or embedding.

### Q9. What is the purpose of StandardScaler and when is it necessary?
**A:** StandardScaler normalises features to zero mean and unit variance. It's essential for distance-based models (KNN, SVR) and gradient-based models (Linear Regression) where features with larger scales dominate. It's not strictly necessary for tree-based models (Decision Tree, Random Forest, Gradient Boosting) because trees split on rank order, not magnitude. I applied it to all numeric features in the preprocessing pipeline to ensure correctness across all model types.

### Q10. How does your Flask application handle a new car prediction?
**A:** The user fills the form → Flask receives POST data → the `predict_price()` function builds a single-row DataFrame with the same column structure as training data → applies the same `engineer_features()` function to create all 22 features → passes the row through the saved sklearn Pipeline (which applies the fitted ColumnTransformer then the Gradient Boosting model) → returns the predicted price in LKR Lakhs. The entire preprocessing is encapsulated in the pipeline so the web app cannot apply preprocessing inconsistently.

### Q11. What is the MAPE metric and what does yours mean?
**A:** MAPE (Mean Absolute Percentage Error) is the average of absolute percentage errors: mean(|actual - predicted| / actual) × 100. A MAPE of ~17% means on average the prediction is within 17% of the actual price. For a car worth 50 Lakhs, this means ±8.5 Lakhs average error. MAPE is useful because it's scale-independent, making it comparable across different price ranges. However, it's undefined when actual price is zero, which we handle by masking zero values.

### Q12. How would you improve the model accuracy further?
**A:** (1) Integrate XGBoost/LightGBM/CatBoost — gradient boosting with better regularisation typically gives 2–5% R² improvement; (2) Add SHAP-based feature selection to remove weakly predictive features; (3) Use target encoding for `brand` and `town` instead of ordinal encoding to encode price information directly; (4) Collect more data, especially for rare brands; (5) Build separate models per fuel type or brand tier (stratified modelling); (6) Apply Bayesian Optimisation instead of RandomizedSearchCV for more efficient hyperparameter search.

### Q13. What assumptions does your model make?
**A:** (1) The training data is representative of the current Sri Lankan market; (2) Future listings will follow similar feature distributions; (3) The relationship between features and price is stationary (doesn't change dramatically over time); (4) Price outliers (top 1%) represent genuine market extremes worth excluding from training; (5) Missing values in the dataset follow a missing-at-random pattern (handled by median/mode imputation).

### Q14. Explain the bias-variance tradeoff in context of your models.
**A:** Bias is a model's tendency to make systematic errors (underfitting); variance is sensitivity to training data fluctuations (overfitting). Linear models have high bias / low variance — they're too simple but consistent. An untuned Decision Tree has low bias / high variance — it fits training data perfectly but varies wildly. Random Forest and Gradient Boosting achieve low bias AND low variance by combining many trees: bagging (RF) reduces variance by averaging; boosting (GB) reduces bias by iteratively correcting errors. This is why ensemble models dominate the leaderboard.

### Q15. What ethical considerations apply to this project?
**A:** (1) The model should not discriminate based on dealer identity or any protected attribute; (2) Predictions should be presented as estimates with uncertainty ranges, not definitive valuations; (3) Data privacy: no personally identifiable information from sellers was retained; (4) The disclaimer on the result page explicitly states this is an ML estimate, not a professional appraisal; (5) Model fairness: predictions for rare brands with few training examples may be less reliable — this should be communicated to users.
