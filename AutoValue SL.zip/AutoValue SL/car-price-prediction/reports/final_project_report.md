# Car Price Prediction Using Machine Learning
## Final Year Academic Project Report

**Department:** Computing / Information Technology  
**Academic Year:** 2024 / 2025  
**Project Title:** AutoValue SL – Intelligent Car Price Prediction System for Sri Lanka  
**Technology Stack:** Python · Scikit-learn · Flask · Bootstrap 5  

---

## Abstract

This project presents AutoValue SL, a machine learning–based car price prediction system tailored for the Sri Lankan used vehicle market. The system processes a real-world dataset of 9,788 vehicle listings, applying comprehensive data preprocessing, feature engineering, and the systematic comparison of eleven regression models. The Gradient Boosting Regressor was identified as the optimal model (Test R² = 0.8744, Test RMSE ≈ 15.3 LKR Lakhs), selected for its combination of high accuracy and controlled generalisation gap. The final model is deployed via a modern, responsive Flask web application that provides real-time price predictions to end users. Special attention is paid throughout to detecting and mitigating overfitting and underfitting, with dedicated regularisation techniques, cross-validation, and hyperparameter tuning applied at every stage of the pipeline.

---

## 1. Introduction

The used car market in Sri Lanka is one of the most active consumer goods markets on the island, with thousands of vehicles changing hands each month. Pricing in this market is largely opaque—buyers and sellers rely on informal knowledge, negotiation, and listings on marketplace websites with no standardised pricing mechanism. This information asymmetry disadvantages buyers who may overpay and sellers who may underprice their vehicles.

Machine learning offers a data-driven solution: by training a regression model on historical listing data, we can build a system that estimates the fair market price of a vehicle based on its measurable attributes. This project does exactly that, building a full pipeline from raw data to a deployed web application.

---

## 2. Problem Statement

**Core Problem:** Buyers and sellers in Sri Lanka's used car market lack access to an objective, data-driven price estimation tool. Existing marketplace platforms show asking prices but provide no market-benchmarked valuations.

**Key Challenges:**
- Price depends on a complex interaction of brand, age, mileage, fuel type, location, and features
- High variance: prices range from LKR 2.65 Lakhs to 225+ Lakhs
- Categorical variables (brand, town) have high cardinality
- Non-linear relationships (e.g. luxury brand premium, exponential mileage depreciation)

---

## 3. Objectives

1. Build a machine learning model that accurately predicts used car prices in Sri Lanka
2. Achieve Test R² ≥ 0.85 with controlled overfitting (gap ≤ 0.10)
3. Systematically compare ≥ 10 regression models and justify the final selection
4. Engineer meaningful features that improve model performance
5. Explicitly detect and mitigate overfitting and underfitting
6. Deploy the model in a production-quality Flask web application
7. Provide comprehensive documentation suitable for academic submission

---

## 4. Literature Review

### 4.1 Machine Learning for Car Price Prediction

Multiple studies have applied regression models to car price prediction. Gegic et al. (2019) demonstrated that Random Forest outperformed linear models on a used car dataset, achieving R² > 0.85. Pudaruth (2014) showed that decision tree–based methods generalise better than linear regression for heterogeneous vehicle datasets. More recent work by Listiani (2009) established that Support Vector Regression can model non-linear pricing relationships but requires careful kernel selection.

### 4.2 Ensemble Methods

Gradient Boosting (Friedman, 2001) is widely regarded as one of the most effective regression approaches for structured tabular data. It builds models sequentially, with each tree correcting the residual errors of the previous one. Research consistently shows it outperforms Random Forest on datasets with complex feature interactions.

### 4.3 Overfitting in Regression Models

The bias-variance tradeoff (Geman et al., 1992) is the theoretical foundation for understanding overfitting. High-variance models (e.g. unpruned decision trees) memorise training data; high-bias models (e.g. linear regression on non-linear data) underfit. Regularisation (Tibshirani, 1996; Hoerl & Kennard, 1970) and ensemble averaging are the two principal strategies to control this tradeoff.

### 4.4 Feature Engineering

Domain-specific feature engineering consistently improves model performance. For vehicle pricing, derived features such as car age, mileage per year, and log-transformed continuous variables are well-established in the literature (Monburinon et al., 2018).

---

## 5. Methodology

### 5.1 System Architecture

```
Raw CSV Data
    ↓
Data Loading (pandas)
    ↓
Data Cleaning (duplicates, outliers, range checks)
    ↓
Feature Engineering (22 features from 16 raw columns)
    ↓
Train/Test Split (80/20, random_state=42)
    ↓
Preprocessing Pipeline (StandardScaler + OrdinalEncoder)
    ↓
Model Training (11 models × 5-fold CV)
    ↓
Hyperparameter Tuning (RandomizedSearchCV, top 3)
    ↓
Model Selection (adjusted test R²)
    ↓
Model Persistence (joblib)
    ↓
Flask Web Application (inference + UI)
```

### 5.2 Dataset

**Source:** Sri Lankan online vehicle marketplace listings (2024–2025)  
**Original records:** 9,788 | **After cleaning:** 8,914  
**Features:** 16 original → 22 engineered  
**Target:** Price (LKR Lakhs)

---

## 6. Data Preprocessing

### 6.1 Data Quality Issues Found

| Issue | Count | Resolution |
|-------|-------|-----------|
| Duplicate rows | 18 | Removed |
| Price > 99th percentile (>225L) | 46 | Removed (extreme outliers) |
| Year < 1990 | ~12 | Removed (data quality) |
| Engine CC outside [500, 5000] | few | Removed |
| Missing values | 0 | No imputation needed |

### 6.2 Column Cleaning

Raw column names such as `Engine (cc)` and `Millage(KM)` were standardised to `engine_cc` and `mileage_km` using regex-based cleaning followed by explicit renaming.

### 6.3 Feature Engineering

Twenty-two features were constructed:

**Derived Numeric Features:**
- `car_age = 2025 - year` (primary depreciation proxy)
- `mileage_per_year = mileage_km / max(car_age, 1)` (wear rate)
- `log_mileage`, `log_engine_cc`, `log_car_age` (reduce right skew)
- `listing_year`, `listing_month` (seasonality signal)

**Binary Flags:**
- `has_ac`, `has_ps`, `has_pm`, `has_pw` (0/1 amenity presence)
- `amenity_score` = sum of above four flags (0–4)
- `is_leasing`, `is_new`, `is_auto` (transaction/vehicle characteristics)
- `is_luxury` = 1 if brand ∈ {BMW, Mercedes-Benz, Audi, Porsche, Lexus, Volvo, Jaguar, Land Rover}

### 6.4 Preprocessing Pipeline

```python
ColumnTransformer(
    Numeric  → SimpleImputer(median) → StandardScaler,
    Binary   → SimpleImputer(0),
    Categorical → SimpleImputer(most_frequent) → OrdinalEncoder
)
```

Sklearn Pipeline ensures no data leakage: the preprocessor is fitted only on training data and applied identically to test data and at inference time.

---

## 7. Exploratory Data Analysis

### 7.1 Price Distribution

- **Mean:** ~53.4 Lakhs | **Median:** ~43.0 Lakhs | **Std:** ~43.6 Lakhs
- **Highly right-skewed** (skewness ≈ 2.8): most cars are in the 20–80 Lakh range; a small number exceed 150 Lakhs
- After 99th percentile capping, range is 2.65 – 225 Lakhs

### 7.2 Key Correlations

- `year` has strong **positive** correlation with price (r ≈ +0.55): newer cars are worth more
- `mileage_km` has **negative** correlation (r ≈ -0.35): higher mileage → lower price
- `car_age` has strong **negative** correlation (r ≈ -0.57): older cars are cheaper
- `engine_cc` has moderate positive correlation (r ≈ +0.30): larger engines → higher price

### 7.3 Brand Pricing

- **Luxury brands** (BMW, Mercedes, Audi) have median prices 3–8× higher than mass-market brands
- **Toyota** is the most common brand (3,089 listings, ~35% of market)
- **Hybrid** vehicles command a premium over equivalent petrol models

### 7.4 Geographic Patterns

- **Colombo** has the highest median prices (proximity to port, urban premium)
- **Rural districts** show lower prices for equivalent vehicles

---

## 8. Model Building

### 8.1 Models Trained

Eleven regression models were trained using the same preprocessing pipeline and evaluated under identical conditions:

1. Linear Regression (baseline)
2. Ridge Regression (L2 regularisation)
3. Lasso Regression (L1 regularisation)
4. ElasticNet (L1+L2)
5. Decision Tree Regressor
6. Random Forest Regressor
7. Extra Trees Regressor
8. Gradient Boosting Regressor
9. AdaBoost Regressor
10. K-Nearest Neighbours Regressor
11. Support Vector Regressor

### 8.2 Evaluation Framework

For each model:
- Trained on 80% training set (n = 7,131)
- Evaluated on 20% test set (n = 1,783)
- 5-fold cross-validation on training data
- Metrics: R², MAE, RMSE, MAPE

---

## 9. Hyperparameter Tuning

The top 3 models (Gradient Boosting, Random Forest, Extra Trees) were tuned using `RandomizedSearchCV` with 5-fold cross-validation.

### Gradient Boosting Tuning Space
```python
{
    "n_estimators"  : [100, 150, 200, 300],
    "learning_rate" : [0.02, 0.05, 0.1],
    "max_depth"     : [3, 4, 5, 6],
    "subsample"     : [0.7, 0.8, 0.9, 1.0],
    "min_samples_leaf": [3, 5, 10],
}
```

Optimal found: `n_estimators=150, learning_rate=0.05, max_depth=5, subsample=0.8`

---

## 10. Overfitting and Underfitting Analysis

*(Full analysis in dedicated report: `reports/overfitting_underfitting_report.md`)*

### Summary

**Models with overfitting (gap > 0.10):**
- Extra Trees (gap = 0.113) — corrected by max_depth, not selected as final

**Models with underfitting (Train R² < 0.70):**
- ElasticNet (Train R² = 0.585) — excessive regularisation
- SVR (Train R² = 0.520) — wrong kernel family for this data

**Final model (Gradient Boosting):**
- Gap = 0.043 (well within acceptable range)
- Regularisation via: low learning_rate, max_depth=5, subsample=0.8
- **Conclusion:** Neither overfitting nor underfitting; strong generalisation

---

## 11. Final Model Selection

**Selected Model:** Gradient Boosting Regressor  
**Rationale:**

| Criterion | Gradient Boosting | Random Forest |
|-----------|------------------|---------------|
| Test R² | **0.8744** | 0.8707 |
| CV R² | **0.8660** | 0.8621 |
| Gap | **0.043** | 0.062 |
| Adjusted Score | **0.874** | 0.867 |
| Winner | ✅ | — |

The selection algorithm penalises the generalisation gap, ensuring the chosen model truly generalises rather than appearing accurate on training data only.

---

## 12. Web Application Design

### Architecture

```
User Browser → Flask Routes → Prediction Pipeline → Response
                  ↓
           Jinja2 Templates
                  ↓
           Bootstrap 5 + Custom CSS (Syne + DM Sans fonts)
```

### Pages

| Page | Purpose |
|------|---------|
| `/` | Home page: hero section, how-it-works, features |
| `/predict` | Prediction form with validation and amenity toggles |
| `/performance` | Model comparison charts and metrics table |
| `/about` | Project overview, dataset details, tech stack |
| `/api/predict` | JSON endpoint for programmatic access |

### Design Choices

- **Dark navy theme** with electric blue accents — conveys precision and technology
- **Syne font** (display) + **DM Sans** (body) — distinctive, non-generic pairing
- **Animated price counter** on result page — engaging user experience
- **Amenity toggles** — intuitive binary input via click-to-toggle cards
- **Price range gauge** — communicates prediction uncertainty visually

---

## 13. Results and Discussion

### Model Performance

The Gradient Boosting model achieves **R² = 0.8744**, meaning it explains 87.44% of the variance in Sri Lankan used car prices. The Mean Absolute Error of approximately 11 LKR Lakhs on a median price of 43 Lakhs represents an error rate of ~25%, which is competitive for this domain given the high inherent variability in subjective car condition.

### Key Findings

1. **Brand is the most important predictor** (~35% feature importance). In the Sri Lankan market, brand status carries a strong premium beyond objective metrics.
2. **Car age and mileage together** account for ~25% of importance. A 10-year-old car with 150,000 KM is valued very differently from a 3-year-old car with 30,000 KM.
3. **Linear models are insufficient** — R² ≈ 0.67 for Ridge/Linear Regression vs. 0.87 for Gradient Boosting, confirming highly non-linear pricing relationships.
4. **Fuel type matters**: Hybrid vehicles command 15–25% premium over equivalent petrol models.
5. **Geographic effects are real**: Colombo listings average higher prices than equivalent vehicles listed in rural districts.

### Limitations

1. The model was trained on listing prices, not actual transaction prices (actual sale may differ)
2. Physical condition, service history, and accident history are not captured
3. Market price fluctuations due to import duty changes are not modelled
4. Rare/exotic models may have insufficient training examples

---

## 14. Conclusion

AutoValue SL successfully demonstrates a complete, production-quality machine learning pipeline for used car price prediction in Sri Lanka. The Gradient Boosting model achieves competitive accuracy (R² = 0.8744) while maintaining good generalisation (train-test gap = 0.043). The project demonstrates strong command of:

- End-to-end data science workflow
- Feature engineering and domain knowledge application
- Multi-model comparison and evaluation
- Overfitting/underfitting detection and mitigation
- Production-quality web application development

The deployed Flask application provides practical value to Sri Lankan car buyers and sellers, delivering instant, data-driven price estimates.

---

## 15. Future Scope

1. **Advanced Boosting:** XGBoost, LightGBM, CatBoost (expected 2–5% R² improvement)
2. **SHAP Explainability:** Per-prediction feature attribution for transparency
3. **Image Valuation:** CNN-based assessment of vehicle condition from photos
4. **Real-time Data Pipeline:** Automated web scraping for continuous model updates
5. **Mobile Application:** React Native app using the JSON API
6. **Cloud Deployment:** AWS EC2 or Heroku for public access
7. **Price Trend Analysis:** Time-series forecasting of depreciation curves

---

## References

1. Friedman, J.H. (2001). Greedy function approximation: A gradient boosting machine. *Annals of Statistics*, 29(5), 1189–1232.
2. Tibshirani, R. (1996). Regression shrinkage and selection via the lasso. *JRSS-B*, 58(1), 267–288.
3. Hoerl, A.E., Kennard, R.W. (1970). Ridge regression: Biased estimation for nonorthogonal problems. *Technometrics*, 12(1), 55–67.
4. Gegic, E., et al. (2019). Car price prediction using machine learning techniques. *TEM Journal*, 8(1).
5. Breiman, L. (2001). Random forests. *Machine Learning*, 45, 5–32.
6. Scikit-learn: Machine Learning in Python (Pedregosa et al., 2011). *JMLR*, 12, 2825–2830.
