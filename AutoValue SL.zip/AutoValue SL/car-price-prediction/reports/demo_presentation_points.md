# Campus Demo Presentation Points
## AutoValue SL — Car Price Prediction

---

## Slide 1: Title
- Project: AutoValue SL — Sri Lankan Car Price Prediction
- Stack: Python · Scikit-learn · Flask · Bootstrap 5
- Dataset: 9,788 real vehicle listings · 50 brands · 27 districts

## Slide 2: Problem
- Sri Lanka's used car market has high price opacity
- Buyers and sellers lack objective pricing tools
- Information asymmetry leads to poor deals
- Our solution: ML-powered instant price estimates

## Slide 3: Dataset
- 9,788 listings, 16 features → cleaned to 8,914
- Features: brand, year, engine CC, gear, fuel type, mileage, town, condition, 4 amenity flags
- Target: Price in LKR Lakhs (mean: 54.3, range: 4–225)
- Zero missing values, 18 duplicates removed

## Slide 4: Feature Engineering (Key Innovation)
- Added `car_age` = 2025 - year (more meaningful than raw year)
- Added `mileage_per_year` = mileage / car_age (wear rate)
- Added `is_luxury` flag (BMW, Mercedes, Audi, etc.)
- Log transforms for skewed features (mileage, engine)
- Result: 22 rich features vs 16 raw columns

## Slide 5: Model Comparison (Key Results)
Show the model_comparison.png chart
- Linear models: ~67% accuracy (underfitting — too simple)
- Decision Tree: 84.6% (good)
- Random Forest: 87.4% (great)
- **Gradient Boosting: 87.5% ← WINNER** (best generalisation)
- SVR: 49% (underfitting — kernel not suited)

## Slide 6: Overfitting vs Underfitting
Show overfitting_analysis.png
- No models significantly overfit (all gaps < 0.10)
- Linear models underfit — car pricing is non-linear
- Gradient Boosting: gap of only 0.05 = excellent generalisation
- Key techniques: max_depth, subsample, min_samples_leaf

## Slide 7: Best Model Deep Dive
Show actual_vs_predicted.png and feature_importance.png
- Test R² = 0.875 (explains 87.5% of price variance)
- Test MAE = 7.36 LKR Lakhs (average error)
- Most important features: brand, car_age, engine_cc, mileage
- Residuals approximately normally distributed ✓

## Slide 8: Live Demo — Web Application
**DEMO FLOW:**
1. Open http://localhost:5000
2. Show home page hero section
3. Click "Predict Now"
4. Fill: Toyota, 2018, 1500cc, Automatic, Petrol, 65000 KM, Colombo
5. Click predict → show result page with animated price
6. Navigate to Model Stats page → show all 10 charts
7. Show API endpoint via browser/curl

## Slide 9: Architecture
- data/ → src/ → models/ → app.py → templates/
- sklearn Pipeline encapsulates preprocessing + model
- Joblib serialisation for production-safe model loading
- Flask REST API for programmatic access

## Slide 10: Conclusion & Future Work
- Achieved 87.5% R² on real Sri Lankan market data
- Complete end-to-end ML pipeline with web deployment
- Clear overfitting/underfitting analysis demonstrated
- Future: XGBoost integration (est. +3% R²), SHAP explainability, cloud deployment

---

## Key Numbers to Remember
- **9,788** listings in dataset
- **22** engineered features
- **11** models compared
- **0.875** test R² (best model)
- **7.36 LKR Lakhs** average prediction error
- **0.050** train-test gap (well generalised)
